---@class EFrame.Constants : EP.U3D.LIBRARY.BASE.Constants
local Constants = {}

function Constants.Initialize() end

EFrame.Constants = Constants