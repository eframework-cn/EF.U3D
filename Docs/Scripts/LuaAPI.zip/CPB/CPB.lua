---@class CPB.CGI_Hello
---@field ID int32 required
---@field Desc string required
local CGI_Hello = {}
CPB.CGI_Hello = CGI_Hello

