---@class UnityEngine.MeshCollider : UnityEngine.Collider
---@field sharedMesh UnityEngine.Mesh
---@field convex bool
---@field cookingOptions UnityEngine.MeshColliderCookingOptions
local MeshCollider = {}

UnityEngine.MeshCollider = MeshCollider