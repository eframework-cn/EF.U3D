---@class UnityEngine.AnimationBlendMode : System.Enum
---@field value__ int
---@field Blend UnityEngine.AnimationBlendMode
---@field Additive UnityEngine.AnimationBlendMode
local AnimationBlendMode = {}

UnityEngine.AnimationBlendMode = AnimationBlendMode