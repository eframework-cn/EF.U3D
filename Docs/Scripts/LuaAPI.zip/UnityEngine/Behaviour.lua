---@class UnityEngine.Behaviour : UnityEngine.Component
---@field enabled bool
---@field isActiveAndEnabled bool
local Behaviour = {}

UnityEngine.Behaviour = Behaviour