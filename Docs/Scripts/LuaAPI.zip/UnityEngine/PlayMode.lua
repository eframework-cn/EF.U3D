---@class UnityEngine.PlayMode : System.Enum
---@field value__ int
---@field StopSameLayer UnityEngine.PlayMode
---@field StopAll UnityEngine.PlayMode
local PlayMode = {}

UnityEngine.PlayMode = PlayMode