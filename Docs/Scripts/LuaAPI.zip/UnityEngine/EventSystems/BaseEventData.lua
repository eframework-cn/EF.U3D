---@class UnityEngine.EventSystems.BaseEventData : UnityEngine.EventSystems.AbstractEventData
---@field currentInputModule UnityEngine.EventSystems.BaseInputModule
---@field selectedObject UnityEngine.GameObject
local BaseEventData = {}

UnityEngine.EventSystems.BaseEventData = BaseEventData