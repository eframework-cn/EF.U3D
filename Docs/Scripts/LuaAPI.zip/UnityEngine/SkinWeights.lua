---@class UnityEngine.SkinWeights : System.Enum
---@field value__ int
---@field OneBone UnityEngine.SkinWeights
---@field TwoBones UnityEngine.SkinWeights
---@field FourBones UnityEngine.SkinWeights
---@field Unlimited UnityEngine.SkinWeights
local SkinWeights = {}

UnityEngine.SkinWeights = SkinWeights