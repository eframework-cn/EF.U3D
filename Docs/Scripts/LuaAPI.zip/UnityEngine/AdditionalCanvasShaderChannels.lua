---@class UnityEngine.AdditionalCanvasShaderChannels : System.Enum
---@field value__ int
---@field None UnityEngine.AdditionalCanvasShaderChannels
---@field TexCoord1 UnityEngine.AdditionalCanvasShaderChannels
---@field TexCoord2 UnityEngine.AdditionalCanvasShaderChannels
---@field TexCoord3 UnityEngine.AdditionalCanvasShaderChannels
---@field Normal UnityEngine.AdditionalCanvasShaderChannels
---@field Tangent UnityEngine.AdditionalCanvasShaderChannels
local AdditionalCanvasShaderChannels = {}

UnityEngine.AdditionalCanvasShaderChannels = AdditionalCanvasShaderChannels