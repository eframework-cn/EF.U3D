---@class UnityEngine.SceneManagement.LoadSceneMode : System.Enum
---@field value__ int
---@field Single UnityEngine.SceneManagement.LoadSceneMode
---@field Additive UnityEngine.SceneManagement.LoadSceneMode
local LoadSceneMode = {}

UnityEngine.SceneManagement.LoadSceneMode = LoadSceneMode