---@class UnityEngine.TextAnchor : System.Enum
---@field value__ int
---@field UpperLeft UnityEngine.TextAnchor
---@field UpperCenter UnityEngine.TextAnchor
---@field UpperRight UnityEngine.TextAnchor
---@field MiddleLeft UnityEngine.TextAnchor
---@field MiddleCenter UnityEngine.TextAnchor
---@field MiddleRight UnityEngine.TextAnchor
---@field LowerLeft UnityEngine.TextAnchor
---@field LowerCenter UnityEngine.TextAnchor
---@field LowerRight UnityEngine.TextAnchor
local TextAnchor = {}

UnityEngine.TextAnchor = TextAnchor