---@class UnityEngine.GUIStyleState : System.Object
---@field background UnityEngine.Texture2D
---@field textColor UnityEngine.Color
local GUIStyleState = {}

UnityEngine.GUIStyleState = GUIStyleState