---@class UnityEngine.TouchPhase : System.Enum
---@field value__ int
---@field Began UnityEngine.TouchPhase
---@field Moved UnityEngine.TouchPhase
---@field Stationary UnityEngine.TouchPhase
---@field Ended UnityEngine.TouchPhase
---@field Canceled UnityEngine.TouchPhase
local TouchPhase = {}

UnityEngine.TouchPhase = TouchPhase