---@class UnityEngine.RenderMode : System.Enum
---@field value__ int
---@field ScreenSpaceOverlay UnityEngine.RenderMode
---@field ScreenSpaceCamera UnityEngine.RenderMode
---@field WorldSpace UnityEngine.RenderMode
local RenderMode = {}

UnityEngine.RenderMode = RenderMode