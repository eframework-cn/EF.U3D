---@class UnityEngine.UI.Outline : UnityEngine.UI.Shadow
local Outline = {}

---@param vh UnityEngine.UI.VertexHelper
function Outline:ModifyMesh(vh) end

UnityEngine.UI.Outline = Outline