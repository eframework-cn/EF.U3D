---@class UnityEngine.UI.Atlas : UnityEngine.MonoBehaviour
---@field sprites UnityEngine.Sprite[]
local Atlas = {}

---@param name System.String
---@return UnityEngine.Sprite
function Atlas:GetSprite(name) end

UnityEngine.UI.Atlas = Atlas