---@class UnityEngine.MeshRenderer : UnityEngine.Renderer
---@field additionalVertexStreams UnityEngine.Mesh
---@field enlightenVertexStream UnityEngine.Mesh
---@field subMeshStartIndex int
local MeshRenderer = {}

UnityEngine.MeshRenderer = MeshRenderer