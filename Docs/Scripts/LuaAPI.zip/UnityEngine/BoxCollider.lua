---@class UnityEngine.BoxCollider : UnityEngine.Collider
---@field center UnityEngine.Vector3
---@field size UnityEngine.Vector3
local BoxCollider = {}

UnityEngine.BoxCollider = BoxCollider