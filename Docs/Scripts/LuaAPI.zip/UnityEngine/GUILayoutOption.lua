---@class UnityEngine.GUILayoutOption : System.Object
local GUILayoutOption = {}

UnityEngine.GUILayoutOption = GUILayoutOption