---@class UnityEngine.QueueMode : System.Enum
---@field value__ int
---@field CompleteOthers UnityEngine.QueueMode
---@field PlayNow UnityEngine.QueueMode
local QueueMode = {}

UnityEngine.QueueMode = QueueMode