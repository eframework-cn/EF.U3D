---@class UnityEngine.GUITargetAttribute : System.Attribute
local GUITargetAttribute = {}

UnityEngine.GUITargetAttribute = GUITargetAttribute