---@class UnityEngine.CapsuleCollider : UnityEngine.Collider
---@field center UnityEngine.Vector3
---@field radius float
---@field height float
---@field direction int
local CapsuleCollider = {}

UnityEngine.CapsuleCollider = CapsuleCollider