---@class UnityEngine.SleepTimeout : System.Object
---@field NeverSleep int
---@field SystemSetting int
local SleepTimeout = {}

UnityEngine.SleepTimeout = SleepTimeout