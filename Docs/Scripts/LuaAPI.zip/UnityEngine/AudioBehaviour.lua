---@class UnityEngine.AudioBehaviour : UnityEngine.Behaviour
local AudioBehaviour = {}

UnityEngine.AudioBehaviour = AudioBehaviour