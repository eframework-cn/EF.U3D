---@class UnityEngine.BatteryStatus : System.Enum
---@field value__ int
---@field Unknown UnityEngine.BatteryStatus
---@field Charging UnityEngine.BatteryStatus
---@field Discharging UnityEngine.BatteryStatus
---@field NotCharging UnityEngine.BatteryStatus
---@field Full UnityEngine.BatteryStatus
local BatteryStatus = {}

UnityEngine.BatteryStatus = BatteryStatus