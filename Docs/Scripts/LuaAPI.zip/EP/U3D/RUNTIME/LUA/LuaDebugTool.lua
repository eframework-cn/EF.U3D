---@class EP.U3D.RUNTIME.LUA.LuaDebugTool : System.Object
local LuaDebugTool = {}

---@param obj System.Object
---@return table
function LuaDebugTool.getUserDataInfo(obj) end

EP.U3D.RUNTIME.LUA.LuaDebugTool = LuaDebugTool