---@class EP.U3D.RUNTIME.LUA.LuaValueInfo : System.Object
---@field name System.String
---@field valueType System.String
---@field valueStr System.String
---@field isValue bool
local LuaValueInfo = {}

EP.U3D.RUNTIME.LUA.LuaValueInfo = LuaValueInfo